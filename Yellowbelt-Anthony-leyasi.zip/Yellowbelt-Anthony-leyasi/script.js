function hide(el) {
    el.remove();
}


var likes = [3, 3, 3];
var spans = [
    document.querySelector("#post-1"),
    document.querySelector("#post-2"),
    document.querySelector("#post-3")
];
var num = 3;
var num02 = 3;
var num03 = 3;
var num1 = document.querySelector(".num");
var num2 = document.querySelector(".num2");
var num3 = document.querySelector(".num3");
function petb() {
    num++;
    num1.innerText = num + "petings";

}
function petb2() {
    num02++;
    num2.innerText = num02;

}
function petb3() {
    num03++;
    num3.innerText = num03;

}


function chosePet(element) {
    alert("You picked " + element.value);
}